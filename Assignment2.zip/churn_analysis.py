"""
Customer Churn Prediction using Logistic Regression
Telco Customer Churn Dataset
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report
)

pd.set_option("display.max_columns", None)

# ---------------------------------------------------------------
# TASK 1: DATA UNDERSTANDING
# ---------------------------------------------------------------
print("="*70)
print("TASK 1: DATA UNDERSTANDING")
print("="*70)

df = pd.read_csv("/mnt/user-data/uploads/WA_Fn-UseC_-Telco-Customer-Churn.csv")

print("\nShape of dataset:", df.shape)

print("\nFirst 5 records:")
print(df.head())

print("\nColumn data types:")
print(df.dtypes)

# TotalCharges is read as object/string because 11 rows contain blank " "
# values (new customers with tenure = 0). Convert to numeric.
df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")

target_variable = "Churn"

numerical_features = ["tenure", "MonthlyCharges", "TotalCharges", "SeniorCitizen"]

categorical_features = [
    col for col in df.columns
    if col not in numerical_features + [target_variable, "customerID"]
]

print("\nTarget variable:", target_variable)
print("\nNumerical features (", len(numerical_features), "):", numerical_features)
print("\nCategorical features (", len(categorical_features), "):")
print(categorical_features)

# ---------------------------------------------------------------
# TASK 2: DATA PREPROCESSING
# ---------------------------------------------------------------
print("\n" + "="*70)
print("TASK 2: DATA PREPROCESSING")
print("="*70)

print("\nMissing values per column BEFORE handling:")
print(df.isnull().sum()[df.isnull().sum() > 0])

# customerID is a unique identifier -> drop, not useful for modeling
df.drop(columns=["customerID"], inplace=True)

# Handle missing values in TotalCharges (11 rows, tenure = 0 -> new
# customers who haven't been billed yet). Impute with 0, which is the
# logical/true value for a customer who has just joined.
df["TotalCharges"] = df["TotalCharges"].fillna(0)

print("\nMissing values per column AFTER handling:")
print(df.isnull().sum().sum(), "missing values remaining")

# Encode target variable: Yes -> 1, No -> 0
df["Churn"] = df["Churn"].map({"Yes": 1, "No": 0})

# Encode categorical features using Label Encoding
label_encoders = {}
for col in categorical_features:
    le = LabelEncoder()
    df[col] = le.fit_transform(df[col])
    label_encoders[col] = le

print("\nData after encoding (first 5 rows):")
print(df.head())

# Features and target
X = df.drop(columns=["Churn"])
y = df["Churn"]

# Train-test split: 80% train, 20% test
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, stratify=y
)

print("\nTraining set size:", X_train.shape)
print("Testing set size:", X_test.shape)

# Scale numerical features (helps Logistic Regression convergence)
scaler = StandardScaler()
X_train_scaled = X_train.copy()
X_test_scaled = X_test.copy()
X_train_scaled[numerical_features] = scaler.fit_transform(X_train[numerical_features])
X_test_scaled[numerical_features] = scaler.transform(X_test[numerical_features])

# ---------------------------------------------------------------
# TASK 3: MODEL DEVELOPMENT
# ---------------------------------------------------------------
print("\n" + "="*70)
print("TASK 3: MODEL DEVELOPMENT")
print("="*70)

model = LogisticRegression(max_iter=1000, random_state=42)
model.fit(X_train_scaled, y_train)

y_pred = model.predict(X_test_scaled)
y_pred_proba = model.predict_proba(X_test_scaled)[:, 1]

print("\nModel trained successfully: Logistic Regression")
print("Number of features used:", X_train_scaled.shape[1])

coef_df = pd.DataFrame({
    "Feature": X.columns,
    "Coefficient": model.coef_[0]
}).sort_values(by="Coefficient", key=abs, ascending=False)
print("\nTop 10 most influential features:")
print(coef_df.head(10).to_string(index=False))

# ---------------------------------------------------------------
# TASK 4: MODEL EVALUATION
# ---------------------------------------------------------------
print("\n" + "="*70)
print("TASK 4: MODEL EVALUATION")
print("="*70)

acc = accuracy_score(y_test, y_pred)
prec = precision_score(y_test, y_pred)
rec = recall_score(y_test, y_pred)
f1 = f1_score(y_test, y_pred)
cm = confusion_matrix(y_test, y_pred)

print(f"\nAccuracy  : {acc:.4f}")
print(f"Precision : {prec:.4f}")
print(f"Recall    : {rec:.4f}")
print(f"F1-Score  : {f1:.4f}")

print("\nConfusion Matrix:")
print(cm)

print("\nClassification Report:")
print(classification_report(y_test, y_pred, target_names=["No Churn", "Churn"]))

# Save confusion matrix plot
plt.figure(figsize=(6, 5))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
            xticklabels=["No Churn", "Churn"],
            yticklabels=["No Churn", "Churn"])
plt.title("Confusion Matrix - Logistic Regression")
plt.ylabel("Actual")
plt.xlabel("Predicted")
plt.tight_layout()
plt.savefig("/home/claude/project/outputs/confusion_matrix.png", dpi=150)
plt.close()

# Save feature importance plot
plt.figure(figsize=(8, 6))
top_feats = coef_df.head(10)
colors = ["#d62728" if c > 0 else "#2ca02c" for c in top_feats["Coefficient"]]
plt.barh(top_feats["Feature"], top_feats["Coefficient"], color=colors)
plt.xlabel("Coefficient (impact on churn log-odds)")
plt.title("Top 10 Feature Importance - Logistic Regression")
plt.gca().invert_yaxis()
plt.tight_layout()
plt.savefig("/home/claude/project/outputs/feature_importance.png", dpi=150)
plt.close()

# Save metrics summary to a text file
with open("/home/claude/project/outputs/model_metrics.txt", "w") as f:
    f.write("Customer Churn Prediction - Logistic Regression\n")
    f.write("="*50 + "\n\n")
    f.write(f"Accuracy  : {acc:.4f}\n")
    f.write(f"Precision : {prec:.4f}\n")
    f.write(f"Recall    : {rec:.4f}\n")
    f.write(f"F1-Score  : {f1:.4f}\n\n")
    f.write("Confusion Matrix:\n")
    f.write(str(cm) + "\n\n")
    f.write("Classification Report:\n")
    f.write(classification_report(y_test, y_pred, target_names=["No Churn", "Churn"]))

print("\nOutputs saved to /home/claude/project/outputs/")
print("\nDONE.")
